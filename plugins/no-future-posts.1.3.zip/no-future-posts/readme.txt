=== No Future Posts ===
Contributors: Tom Braider
Tags: posts, future, events
Requires at least: 3.0
Tested up to: 3.4.1
Stable tag: 1.3
License: Postcardware :)
Donate link: http://www.tomsdimension.de/postcards

Makes your blog to a simple "Event Calendar"

== Description ==

Changes the status of all "future" posts to "publish".
So future posts will show in your blog like other posts.
I use it to show events. No calendar plugin is needed.

Exclude list for posts and categories.

== Installation ==

1. unzip plugin directory into the '/wp-content/plugins/' directory
1. activate the plugin through the 'Plugins' menu in WordPress
1. check and save the options page

== Frequently Asked Questions ==

= Need Help? Find Bug? =

read and write comments on <a href="http://www.tomsdimension.de/wp-plugins/no-future-posts">plugin page</a>

== Screenshots ==

1. Settings

== Arbitrary section ==

**Known Issues**

+ Post counter in the category list not always up to date. Just save an aldready published post in this categorie.

== Changelog ==

= 1.3 =

+ bugifx: excluded categories
+ code optimization and cleanup
+ new language: Lithuanian, thanks to Vincent G http://host1free.com
+ new language: Romanian, thanks to Alexander Ovsov http://webhostinggeeks.com
  
= 1.2.1 =

+ new language: russian, thanks Marcis Gasuns

= 1.2 =

+ new: uninstall function for wp 2.7

= 1.1 =

+ new: exclude lists for posts and categories
+ new: languages english, german

= 1.0 =

+ first release
